#include<iostream>
#include<iostream>
#include<conio.h>
#include<conio.h>
#include<string>
#include<fstream>
void reciept();
void invalidMenu();
void attempts();
struct login//structure for user login and create account.
{
	int Password;
	int Widhrawl = 0;
	int deposite = 500000;//amount present in account.
	int Deposite = 0;//New amount user want to deposite in account
	int RemainingBalance = deposite;
	int NewBalance;

};
int remain(int, int);//decleration of remaing balance function.
void menu();//selection to create or login an account.
void accounts();//login or create account.
void usermenu();//display the menu of user logged-in.
int add(int, int);
using namespace std;
int main()
{
	cout << "************************************************************************************************************************";
	cout << "------------------------------------------------------------------------------------------------------------------------";
	cout << "\t\t\t\t\t \" WELCOME TO BJ BANK pvt ltd.\" \n";
	cout << "========================================================================================================================";
	cout << "\t\t\t\t\t \" WELCOME TO BJ ATM MACHINE. \"\n";
	cout << "------------------------------------------------------------------------------------------------------------------------";
	cout << "************************************************************************************************************************";

	menu();

	_getch();
	return 0;
}
int remain(int num1, int num2) //implementation of function for the subtraction of integers.
{
	int result = num1 - num2;
	return result;
}
int add(int n1, int n2)//implementation tu add two integers
{
	int sum = n1 + n2;
	return sum;
}
void menu()//implementation of the main menu
{
	cout << "\n >> \" WELCOME!! \" << \n >> ENTER YOUR CARD AND TO PRESS 1 LOG-IN :\n >> PRESS 2 TO CREATE NEW ACCOUNT :  ";
	cout << "\n";
	//system("pause");
	accounts();
}
void usermenu()//implementation of the user menu.
{
	cout << "\n\n PICK YOUR REQUIRED OPTION : \n\n >> OPTIONS <<  ";

	cout << "\n\n Press 1 for Cash-deposite \n Press 2 for Cash-Widhrawl \n Press 3 to check Remaining-Balance \n Press 4 to Print reciept \n Press 5 to Change Password \n Press 6 to EXIT. \n";
}
void accounts()//implementation the main(core) structure.
{//braket for the structure started

	login user;
	int attempt = 3;
	int i = 3;
	string password;
	string OldPass;
	string pass = "1234";
	char ch;
	cout << "\n ";
	cin >> ch;
	do
	{////do-while loop for error reduction started for main choices.
		

		if (ch == '1')
		{//if for login started.
		step1:
			cout << "\n \t\t\t NOTE:\" YOU HAVE ONLY 3 CHANCES TO ENTER PASSWORD: \"";
			fstream userdata;
			userdata.open("data.txt", ios::in);//opening/creation of file //ios::in used to read data from file
			char name[1000];
			char pass[1000];
			char in_pass[1000];//input password by user.
			string r = "";
		
			cout << "\n Enter your 4-Digit Password : ";
			cin.ignore();//ignore spaces etc
			cin.getline(in_pass, 1000);
			int x = 0;
			while (!userdata.eof())//whle loop will run till end of f

			{//loop for the reading of data from filee till end of file.bracket started.
				userdata.getline(name, 1000, '\t');
				userdata.getline(pass, 1000, '\t');
				if (strcmp(pass, in_pass) == 0 && in_pass != r)//if for correct password started.
				{//IF bracket started if password is correct



				step2:

					usermenu();
					char choice;
					cout << " ";
					cin >> choice;

					do
					{//do-whilw\e loop bracket started for error reduction.
						switch (choice)
						{																				//braket of selection of options for old user started.
						case '1':
							cout << "\n Enter Amount You want to deposite in your account\n\t\t NOTE:(donnot Enter negative value or Rs 0) :\n Rs ";
							cin >> user.Deposite;
							if (user.Deposite > 0)
							{

								cout << "\n Your Previous Balance = Rs " << user.deposite;
								user.deposite = user.deposite + user.Deposite;
								cout << "\n New Amount Added = Rs " << user.Deposite;
								cout << "\n Your Total Ammount is : Rs " << user.deposite;





								cout << "\n >>  Do You Want More Transaction or Exit? (y/n): \n";		//choice to continue atm or exit.
								char yn;														//choice to continue atm or exit
								cin >> yn;														//choice to continue atm or exit
								char temp = tolower(yn);										//choice to continue atm or exit
								if (temp == 'y')												//choice to continue atm or exit
								{
									system("cls");
									goto step2;
								}											//choice to continue atm or exit
								else if (temp == 'n')											//choice to continue atm or exit
									cout << "\nTHANK YOU FOR USING OUR SERVICE";				//choice to continue atm or exit
								return;

							}																	//braket of deposite-if  ends.
							else
							{
								cout << "\n Enter a valid Ammount : ";

								usermenu();
							}
							break;
						case '2':
							cout << "\n Enter Widhrawl Amount : Rs ";
							cin >> user.Widhrawl;
							if (user.Widhrawl <= user.RemainingBalance)
							{//braket of widhrawl if started.
								user.deposite = user.deposite - user.Widhrawl;
								cout << "\n Your Remaining Amount = Rs " << user.deposite;

								cout << "\n >>  Do You Want More Transaction or Exit? (y/n): \n";		//choice to continue atm or exit.
								char yn;														//choice to continue atm or exit
								cin >> yn;														//choice to continue atm or exit
								char temp = tolower(yn);										//choice to continue atm or exit
								if (temp == 'y')												//choice to continue atm or exit
								{
									system("cls");
									goto step2;
								}											//choice to continue atm or exit
								else if (temp == 'n')											//choice to continue atm or exit
									cout << "\nTHANK YOU FOR USING OUR SERVICE";				//choice to continue atm or exit

								return;

							}//braket of widhrawl if ended.
							else
							{
								cout << "\n Enter a valid Ammount : ";
								usermenu();
							}
							break;
						case '3':
							cout << "\n Your Remaing-Balance = Rs " << user.deposite;
							goto step2;


							break;
						case '4':

							system("cls");
							cout << "************************************************************************************************************************";
							cout << "------------------------------------------------------------------------------------------------------------------------";
							cout << "\t\t\t\t\t \" WELCOME TO BJ BANK pvt ltd.\" \n";
							cout << "========================================================================================================================";
							cout << "\t\t\t\t\t \" WELCOME TO BJ ATM MACHINE. \"\n";
							cout << "------------------------------------------------------------------------------------------------------------------------";
							cout << "************************************************************************************************************************";
							cout << "\n >> Amounr-Deposite : Rs " << user.Deposite;
							cout << "\n >> Amount-Widhrawl : Rs " << user.Widhrawl;
							cout << "\n >> Your remaining amount : Rs " << user.deposite << endl;
							cout << "\n\t\t\t \" THANK YOU FOR USING OUR SERVICE !!! \" \n GOOD-BYE...";
							goto step2;
							break;
						case '5':

							cout << "\n Enter your OLD password : ";
							cin >> OldPass;
							if (OldPass == pass)
							{
								cout << "\n Enter Your New-Password : ";
								cin >> pass;
								cout << "\n Password SUCCESSFULLY changed..!!! ";
								cout << "\n Press 1 to COntinue Or ANY-KEY to EXIT:\n  ";
								int a;
								cin >> a;
								if (a == 1)
								{
									goto step1;
								}
								else
								{
									cout << "\n Thankyou for using our service \n GOOD-BYE..";
									system("pause");
									return;
								}

							}
							else
							{
								cout << "\n Please try Again : ";
							}

							break;
						case'6':
							return;
							break;
						default:
							OldPass = OldPass;

							system("cls");
							cout << "\n Enter a valid value:\n  ";
							goto step2;
						}// bracket of switch of usermenu ended.

					} while (isalpha(choice));
					x = 1;
					break;
				}



			}
			string empty = "";
			//braket for main switch ended.

			if (x == 0)
			{
				cout << " \nInvalid key,You have one chance left !!!!!!!\n Enter 1  to  TRY-AGAIN!!!!!!!\t Or ANY-KEY TO EXIT: \n";
				char ch;

				cin >> ch;
				if (ch == '1')
				{

					fstream userdata;
					userdata.open("data.txt", ios::in);
					char name[1000];
					char pass[1000];
					char n_pass[1000]; /// inpit password from user

					cout << " \n Enter the 4-digits pin : ";
					cin.ignore();
					cin.getline(n_pass, 1000);
					int x = 0;
					while (!userdata.eof())
					{
						userdata.getline(name, 1000, '\t');
						userdata.getline(pass, 1000, '\t');
						if (strcmp(pass, n_pass) == 0 && n_pass != r)
						{
							goto step2;
							x = 1;
							break;
						}
					}
					if (x == 0)
					{
						cout << " \n Invalid key!!!you have last chance !!!! Enter 1 to continue!!!\n";
						int i;

						cin >> i;
						if (i == 1){

							fstream userdata;
							userdata.open("data.txt", ios::in);
							char name[1000];
							char pass[1000];
							char n_pass[1000];// input of passowrd by user

							cout << " \n Enter the 4-digits pin : ";
							cin.ignore();
							cin.getline(n_pass, 1000);
							int x = 0;
							while (!userdata.eof())
							{
								userdata.getline(name, 1000, '\t');
								userdata.getline(pass, 1000, '\t');
								if (strcmp(pass, n_pass) == 0 && n_pass != r)
								{
									goto step2;
									x = 1;
									break;
								}
							}
							if (x == 0)
							{
								cout << " \nInvalid key!!! you have reach maximum attempts !!!!\n";


								cout << " \n Please take your card bye !!!!\n";
								return;
							}
						}
						userdata.close();

					}
				}
				userdata.close();

			}

		



	
	}//if for login ended.
	if (ch == '2')
	{
		system("cls");
		char username[1000];
		cout << "\n\n ENTER YOUR NAME : ";
		cin >> username;
		string cnic;
	
		cout << "\n ENTER A 4-DIGIT PASSWORD : ";
		cin >> password;
		
		ofstream userdata;
		userdata.open("data.txt", ios::app);
		cin.ignore();
		userdata << "RECORD = ";
		userdata << username << "\t" << password << "\t" << "\n";
		cout << "\n ACCOUNT SUCCESSFULLY CREATED...\n  ";
		userdata.close();
		goto step1;
		break;
	}
	else
	{
		system("cls");

		cout << "\n ENTER A VALID VALUE:\n ";
		menu();
	}

	
	}while (isalpha(ch));////do-while loop for error reduction started for main choices, bracket ended. 
	

	}//braket for the structure ended.


	